import pandas as pd
import matplotlib.pyplot as plt
import os

os.makedirs("output", exist_ok=True)

# Load Dataset
df = pd.read_csv("data/employee_data.csv")

print("="*50)
print("ORIGINAL DATASET")
print("="*50)
print(df.head())

# Dataset Information
print("\nDataset Information")
print(df.info())

print("\nMissing Values")
print(df.isnull().sum())

print("\nDuplicate Rows")
print(df.duplicated().sum())

# Store original row count
original_rows = len(df)

# Remove Duplicate Rows
df = df.drop_duplicates()

# Handle Missing Values

# Fill Age with average
df["Age"] = df["Age"].fillna(df["Age"].mean())

# Fill Salary with average
df["Salary"] = df["Salary"].fillna(df["Salary"].mean())

# Fill Department with Unknown
df["Department"] = df["Department"].fillna("Unknown")

# Standardize Department Names
df["Department"] = df["Department"].str.upper()

# Save Cleaned Dataset
df.to_csv("output/cleaned_employee_data.csv", index=False)

print("\nCleaned dataset saved successfully!")

# Summary Statistics
print("\nSummary Statistics")
print(df.describe())

# Department Report
department_report = df["Department"].value_counts()

print("\nEmployees in Each Department")
print(department_report)

# Average Salary by Department
salary_report = df.groupby("Department")["Salary"].mean()

print("\nAverage Salary by Department")
print(salary_report)

# Create Bar Chart
plt.figure(figsize=(8,5))

department_report.plot(kind="bar")

plt.title("Employees by Department")
plt.xlabel("Department")
plt.ylabel("Number of Employees")

plt.tight_layout()

plt.savefig("output/department_report.png")

plt.show()

# Salary Distribution
plt.figure(figsize=(8,5))

plt.hist(df["Salary"], bins=10)

plt.title("Salary Distribution")
plt.xlabel("Salary")
plt.ylabel("Employees")

plt.tight_layout()

plt.savefig("output/salary_distribution.png")

plt.show()

# Age Distribution
plt.figure(figsize=(8,5))

plt.hist(df["Age"], bins=10)

plt.title("Age Distribution")
plt.xlabel("Age")
plt.ylabel("Employees")

plt.tight_layout()

plt.savefig("output/age_distribution.png")

plt.show()

# Generate Automated Report
report = f"""
==========================================
      DATA CLEANING AUTOMATION REPORT
==========================================

Original Number of Rows : {original_rows}

Rows After Cleaning : {len(df)}

Duplicate Rows Remaining : {df.duplicated().sum()}

Missing Values Remaining

{df.isnull().sum()}

Employees by Department

{department_report}

Average Salary by Department

{salary_report}

==========================================
Project Completed Successfully
==========================================
"""

print(report)

with open("output/report.txt", "w") as file:
    file.write(report)

print("Report Generated Successfully!")

print("\nProject Completed Successfully!")